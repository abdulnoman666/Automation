﻿namespace ContourSeleniumTest
    {
    internal partial class AuthenticationPage
        {
        }
    }
